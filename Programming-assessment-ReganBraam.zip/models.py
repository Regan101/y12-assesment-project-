from main import db
### Database tables and columns within each tables ###
class Team(db.Model):
    __tablename__ = 'Team'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80))
    year = db.Column(db.Integer)
    description = db.Column(db.String())
    image = db.Column(db.String())
    worldcup = db.Column(db.Integer)
    imageone = db.Column(db.String())
  


class Player(db.Model):
    __tablename__ = 'Player'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable = False)
    team = db.Column(db.String(250))
    goals = db.Column(db.Integer)
    caps = db.Column(db.Integer)
    birthday  = db.Column(db.String)
    image  = db.Column(db.String)
    position =  db.Column(db.String)
    total_goals = db.Column(db.Integer)
    mintues_played = db.Column(db.Integer)
    value = db.Column(db.String)
    age = db.Column(db.Integer)
  

class Trophy(db.Model):
    __tablename__ = 'Trophy'
    id = db.Column(db.Integer, primary_key=True)
    player = db.Column(db.Integer)
    trophy  = db.Column(db.String)

class Club(db.Model):
    __tablename__ = 'Club'
    id = db.Column(db.Integer, primary_key=True)
    player = db.Column(db.Integer)
    club  = db.Column(db.String)
  
  