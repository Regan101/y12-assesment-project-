#### This is the main page of the program/website it has all the routes on it so it will display properly on all other html pages it also has the database in it which is the bulk of the infomation in the website  ######################
from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy, request


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///football.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# need db to import models
import models


################################## HOME ##################################
###### this route renders the home page in home.html ######
@app.route('/')
def root():
    return render_template('home.html', page_title='HOME')


################################## All_TEAM ##################################
## this route it renders the list of all teams to all_team.html#######
@app.route('/all_team')
def all_team():
    teams = models.Team.query.all()
    return render_template('all_team.html',
                           page_title="All teams",
                           teams=teams)


################################## All_PLAYERS ##################################
## this route it renders the list of all players to all_players.html#######

@app.route('/all_player')
def all_player():
    players = models.Player.query.all()
    return render_template('all_player.html',
                           page_title="All players",
                           players=players)


################################## TEAM ##################################
#### this route pulls the infomation from the databse models and allows it to display on the team.html template ######

@app.route('/team/<int:id>')
def team(id):
    team = models.Team.query.filter_by(id=id).first()
    player = models.Player.query.all()
    team_players = []
    for player in player:
        if player.team == id:
            team_players.append(player)
    name = team.name
    return render_template('team.html',
                           page_title=name,
                           team=team,
                           team_players=team_players)


################################## PLAYER TEST##################################
'''@app.route('/player/<int:id>')
def player(id):
    player = models.Team.query.filter_by(id=id).first()
    teams = models.Player.query.all()
    player_teams = []
    for team in teams:
      if team.player == id:
        player_teams.append(team)
    name = player.name
    return render_template('team.html', page_title=name, player=player, teams=player_teams)'''


################################## PLAYER ##################################
#### this route pulls the infomation from the databse models and allows it to display on the player.html template ######
@app.route('/player/<int:id>')
def player(id):
    player = models.Player.query.filter_by(id=id).first()
    trophys = models.Trophy.query.all()      # this part of the code pulls the trophys table form the database
    teams = models.Team.query.all()
    clubs = models.Club.query.all()
    for team in teams:                 
        if player.team == team.id:       
            player_team = team       
    player_trophies = []
    for trophy in trophys:                ####  this part of the code allows the trophies to be used in the 
        if trophy.player == id:           ####  player.html template 
            player_trophies.append(trophy)####
    player_clubs = []
    for club in clubs:
        if club.player == id:
            player_clubs.append(club)
    name = player.name
    goal_ratio = "{:.2f}".format(player.goals / player.caps)
    games_per_minute = player.mintues_played / 90
    goals_per_game = "{:.2f}".format(player.total_goals /games_per_minute)                       
    return render_template('player.html',
                           page_title=name,
                           player=player,
                           player_trophies=player_trophies,
                           teams=teams,
                           player_clubs=player_clubs,
                           player_team=player_team,
                           goal_ratio=goal_ratio,
                           games_per_minute=games_per_minute,
                           goals_per_game=goals_per_game)



################################## RUN APP ##################################
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=8080)
  
